from django.apps import AppConfig


class OmsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'omsapp'
